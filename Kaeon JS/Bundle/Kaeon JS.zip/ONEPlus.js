var one = require("./ONE");

function readONEPlus(data) {

	// STUB

	return one.readONE(data);
}

module.exports = {
	readONEPlus
};