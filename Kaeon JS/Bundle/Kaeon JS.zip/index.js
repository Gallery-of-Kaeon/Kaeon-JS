// YOUR CODE HERE

// UNCOMMENT THE BLOCK BELOW FOR A KAEON FUSION PROJECT

/*

var kaeonFUSION = require("./KaeonFUSION");
var fusion = new kaeonFUSION.KaeonFUSION();

var data = require("./kaeon").open("./index.op");

for(var i = 0; i < data.length; i++) {

	if(data.charCodeAt(i) == 13) {
		data = data.substring(0, i) + data.substring(i + 1);
		i--;
	}
}

fusion.process(require("./ONEPlus").readONEPlus(data));

 */