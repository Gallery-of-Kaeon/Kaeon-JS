// YOUR CODE HERE

// UNCOMMENT THE BLOCK BELOW FOR A KAEON FUSION PROJECT

/*

var kaeonFUSION = require("./KaeonFUSION");
var fusion = new kaeonFUSION.KaeonFUSION();

fusion.process(require("./ONEPlus").readONEPlus(require("./kaeon").open("./index.op")));

*/