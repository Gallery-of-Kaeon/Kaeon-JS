// YOUR CODE HERE

// UNCOMMENT THE LINE BELOW FOR A KAEON FUSION PROJECT

// new require("./KaeonFUSION").process(require("./ONEPlus").readONEPlus(require("./kaeon").open("./index.op")));