function open(file) {
	
	// STUB

	return "";
}

module.exports = {
	open
};