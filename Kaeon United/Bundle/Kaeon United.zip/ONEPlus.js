var one = require("./ONE.js");

function readONEPlus(data) {

	// STUB

	return one.readONE(data);
}

module.exports = {
	readONEPlus
};